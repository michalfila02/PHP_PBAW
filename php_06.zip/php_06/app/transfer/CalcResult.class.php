<?php
namespace app\transfer;
class CalcResult {
	private $result = array();
    private $num = 0;

    public function addResults($result) {
		$this->result[] = $result;
		$this->num ++;
	}
    public function isEmpty() {
		return $this->num == 0;
	}
    public function getResults() {
		return $this->result;
	}

    public function clear() {
		$this->result = array ();
		$this->num = 0;
	}



} 