<?php
namespace app\forms;
class CalcForm {
	public $a;
	public $b;
	public $c;
    public $delta;
} 