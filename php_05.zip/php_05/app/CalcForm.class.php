<?php
class CalcForm {
	public $a;
	public $b;
	public $c;
    public $delta;
} 