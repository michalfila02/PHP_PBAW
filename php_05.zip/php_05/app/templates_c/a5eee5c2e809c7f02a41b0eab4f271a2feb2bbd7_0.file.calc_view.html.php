<?php
/* Smarty version 4.3.1, created on 2023-05-09 00:14:08
  from 'C:\xampp\htdocs\php_04\app\calc_view.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6459743003ad08_46748003',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a5eee5c2e809c7f02a41b0eab4f271a2feb2bbd7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\php_04\\app\\calc_view.html',
      1 => 1683584044,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6459743003ad08_46748003 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1450695351645974300208d7_53770627', 'footer');
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_25728440864597430021766_10184407', 'content');
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ($_smarty_tpl->tpl_vars['conf']->value->root_path).("/templates/main.html"));
}
/* {block 'footer'} */
class Block_1450695351645974300208d7_53770627 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'footer' => 
  array (
    0 => 'Block_1450695351645974300208d7_53770627',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
	<footer id="footer" class="top-space">

		
	<div class="footer2">
		<div class="container">
			<div class="row">
				
				<div class="col-md-6 widget">
					<div class="widget-body">
						<p class="simplenav">
							<a href="#">Home</a> | 
						</p>
					</div>
				</div>

				<div class="col-md-6 widget">
					<div class="widget-body">
						<p class="text-right">
							Done by Michał Fila. Designed by <a href="http://gettemplate.com/" rel="designer">gettemplate</a> 
						</p>
					</div>
				</div>

			</div> <!-- /row of widgets -->
		</div>
	</div>

</footer>	
<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_25728440864597430021766_10184407 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_25728440864597430021766_10184407',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




<div style="width:90%; margin: 6em auto;">

<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/app/calc.php" method="post" class="pure-form pure-form-stacked">
		<label for="id_a">Liczba a: </label>
		<input id="id_a" type="text" name="a" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->a;?>
" />
		<label for="id_b">Liczba b: </label>
		<input id="id_b" type="text" name="b" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->b;?>
" />
		<label for="id_c">Liczba c: </label>
		<input id="id_c" type="text" name="c" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->c;?>
" />
	<input type="submit" value="Oblicz" class="pure-button pure-button-primary" />
</form>	

<div class="l-box-lrg pure-u-1 pure-u-med-3-5"></div>
<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
	<h4>Wystąpiły błędy: </h4>
	<ol class="err">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getErrors(), 'err');
$_smarty_tpl->tpl_vars['err']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>

<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isInfo()) {?>
	<h4>Informacje: </h4>
	<ol class="inf">
	<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getInfos(), 'inf');
$_smarty_tpl->tpl_vars['inf']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['inf']->value) {
$_smarty_tpl->tpl_vars['inf']->do_else = false;
?>
	<li><?php echo $_smarty_tpl->tpl_vars['inf']->value;?>
</li>
	<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
	</ol>
<?php }?>



<?php if (!($_smarty_tpl->tpl_vars['res']->value->isEmpty())) {?>
		<h4>Wynik:<h4>
		<ol class="res"></p>
		<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['res']->value->getResults(), 'res', false, 'key');
$_smarty_tpl->tpl_vars['res']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['res']->value) {
$_smarty_tpl->tpl_vars['res']->do_else = false;
?>
		<li><?php echo $_smarty_tpl->tpl_vars['res']->value;?>
</li>
		<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
<?php }?>

</div>
</div> 
		
</div>
</div>

</div>	
</div>	
</div>
</div>

		



<?php
}
}
/* {/block 'content'} */
}
