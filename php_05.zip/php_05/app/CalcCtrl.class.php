<?php
require_once $conf->root_path.'../lib/Smarty.class.php';
require_once $conf->root_path.'/app/Messages.class.php';
require_once $conf->root_path.'/app/CalcForm.class.php';
require_once $conf->root_path.'/app/CalcResult.class.php';

class CalcCtrl
{
    private $msgs;   //wiadomości dla widoku
	private $form;   //dane formularza (do obliczeń i dla widoku)
	private $results; //inne dane dla widoku
	private $hide_intro; //zmienna informująca o tym czy schować intro

    

    /**  Konstruktor - inicjalizacja właściwości*/
	public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->msgs = new Messages();
		$this->form = new CalcForm();
		$this->results = new CalcResult();
		$this->hide_intro = false;
	}

    public function getParams(){
		$this->form->a = isset($_REQUEST ['a']) ? $_REQUEST ['a'] : null;
		$this->form->b = isset($_REQUEST ['b']) ? $_REQUEST ['b'] : null;
		$this->form->c = isset($_REQUEST ['c']) ? $_REQUEST ['c'] : null;
	}


// sprawdzenie, czy parametry zostały przekazane
function validate() {
	
	if ( ! (isset($this->form->a )) && (isset($this->form->b )) && (isset($this->form->c ))) {
		//sytuacja wystąpi kiedy np. kontroler zostanie wywołany bezpośrednio - nie z formularza
		return false;
	} else { 
        $this->hide_intro = true; //przyszły pola formularza, więc - schowaj wstęp
    }

	// sprawdzenie, czy potrzebne wartości zostały przekazane
	if ($this->form->a == '') {
		$this->msgs->addError('Nie podano współczynnika a');
	}
	if ($this->form->b == '') {
		$this->msgs->addError('Nie podano współczynnika b');
	}
	if ($this->form->c == '') {
		$this->msgs->addError('Nie podano współczynnika c');
	}

    if (! $this->msgs->isError()) {
		

	//nie ma sensu walidować dalej gdy brak parametrów
	
	// sprawdzenie, czy $a, $b i $c są liczbami całkowitymi
	if (! is_numeric( $this->form->a )) {
		$this->msgs->addError('Wartość współczynnika "a" nie jest liczbą całkowitą');
	}
	if ( $this->form->a == 0 ) {
		$this->msgs->addError('Wartość współczynnika "a" jest równa zero, ergo jest to funkcja liniowa');
	}
	if (! is_numeric( $this->form->b )) {
        $this->msgs->addError('Wartość współczynnika "b" nie jest liczbą całkowitą');
	}
	
	if (! is_numeric( $this->form->c )) {
        $this->msgs->addError('Wartość współczynnika "c" nie jest liczbą całkowitą');
	}
}
return ! $this->msgs->isError();
}
// 3. wykonaj zadanie jeśli wszystko w porządku
function process()
{
	$this->getparams();

    if ($this->validate()) {
	//konwersja parametrów na int
	$this->form->a = intval($this->form->a);
	$this->form->b = intval($this->form->b);
	$this->form->c = intval($this->form->c);
    $this->msgs->addInfo('Parametry poprawne.');
	//obliczenie delty
	$this->form->delta = (($this->form->b ** 2) - (4*$this->form->a*$this->form->c ));  //algorytm liczenia X na podstawie delty

	if($this->form->delta == 0){ 
		$this->results->addResults("Delta: " . $this->form->delta);  // dodanie delty do tablicy wynikowej
		
		$this->results->addResults("X: ". (-$this->form->b) / (2*$this->form->a)); // dodanie obliczonego X do tablicy wynikowej
	}
	else if($this->form->delta  > 0){ 
	
		$this->results->addResults("Delta: " . $this->form->delta);
        $this->form->delta = $this->form->delta ** (1/2);	
	    $this->results->addResults("X1: " . (-$this->form->b+$this->form->delta) / (2*$this->form->a));
	    $this->results->addResults("X2: " . (-$this->form->b-$this->form->delta) / (2*$this->form->a));
	
	}
	else {
	
		$this->msgs->addInfo('Brak rzeczywistych wartości x spełnijących warunek'); // dodanie komunikatu wobec (ax^2+bx+c) != 0 do tablicy wynikowej
		
        $this->results->addResults("Delta: " . $this->form->delta);
		$this->form->delta = -$this->form->delta;
		$this->form->delta = $this->form->delta ** (1/2);	
	    $this->results->addResults("X1: " . ((-$this->form->b) / (2*$this->form->a))."+ i".(($this->form->delta) / (2*$this->form->a)));
	    $this->results->addResults("X2: " . ((-$this->form->b) / (2*$this->form->a))."- i".(($this->form->delta) / (2*$this->form->a)));
	
	}
    $this->msgs->addInfo('Wykonano obliczenia.');
    }

$this->generateView();

}

    
   public function generateView(){
       global $conf;

       $smarty = new Smarty();
       $smarty->assign('conf',$conf);

       $smarty->assign('page_title','Kalkulator Równania Kwadratowego');
       $smarty->assign('app_title','Kalkulator');
       $smarty->assign('page_description','Teraz wykonany w szablonie Progressus');
       $smarty->assign('app_description','Teraz wspiera oblicznie liczb złożonych!');
       $smarty->assign('page_header','Obiekty w PHP');
            
       $smarty->assign('hide_intro',$this->hide_intro);

       $smarty->assign('msgs',$this->msgs);
       $smarty->assign('form',$this->form);
       $smarty->assign('res',$this->results);

       $smarty->display($conf->root_path.'/app/calc_view.html');
       }
}